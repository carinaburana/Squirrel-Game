public enum Commands {
    UP, DOWN, LEFT, RIGHT, SPAWN

}
